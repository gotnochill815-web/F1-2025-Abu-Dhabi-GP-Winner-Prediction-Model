# F1 2025 ABU DHABI GP PREDICTION MODEL - PYTHON SCRIPT
# Copy and run this entire script

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

print("="*60)
print("🏎️  F1 2025 ABU DHABI GP WINNER PREDICTION MODEL")
print("="*60)

# REALISTIC F1 2025 DRIVER DATA
print("
📊 REALISTIC F1 2025 DRIVER PERFORMANCE DATA")
print("-"*50)

driver_data = {
    'Driver': ['Verstappen', 'Hamilton', 'Leclerc', 'Norris', 'Piastri', 
               'Russell', 'Sainz', 'Alonso', 'Stroll', 'Gasly'],
    'Team': ['Red Bull', 'Mercedes', 'Ferrari', 'McLaren', 'McLaren', 
             'Mercedes', 'Ferrari', 'Aston Martin', 'Aston Martin', 'Alpine'],
    'Win_Rate_2024': [0.65, 0.10, 0.15, 0.10, 0.05, 0.05, 0.08, 0.03, 0.00, 0.00],
    'Podium_Rate_2024': [0.85, 0.35, 0.45, 0.40, 0.25, 0.30, 0.35, 0.20, 0.05, 0.10],
    'Avg_Finish_2024': [1.8, 4.5, 3.8, 4.2, 5.5, 5.0, 4.8, 6.5, 9.5, 8.0],
    'Qualifying_Avg': [1.2, 3.8, 2.5, 3.5, 5.0, 4.2, 4.0, 7.0, 10.5, 9.0],
    'Points_2024': [525, 285, 320, 305, 240, 265, 280, 195, 75, 120],
    'Experience_Years': [11, 18, 7, 6, 3, 6, 10, 22, 8, 8],
    'Abu_Dhabi_Wins': [3, 5, 0, 0, 0, 0, 0, 2, 0, 0],
    'Recent_Form': [0.95, 0.85, 0.90, 0.88, 0.82, 0.80, 0.83, 0.75, 0.60, 0.65]
}

df_drivers = pd.DataFrame(driver_data)
print("
Current F1 Drivers 2025 Season:")
print(df_drivers[['Driver', 'Team', 'Win_Rate_2024', 'Avg_Finish_2024']])

# ABU DHABI SCENARIOS
print("

🏁 CREATING ABU DHABI GP 2025 SCENARIOS...")
print("-"*50)

abu_dhabi_performance = {
    'Verstappen': 0.92,
    'Hamilton': 0.88,
    'Leclerc': 0.75,
    'Norris': 0.70,
    'Piastri': 0.65,
    'Russell': 0.68,
    'Sainz': 0.72,
    'Alonso': 0.80,
    'Stroll': 0.55,
    'Gasly': 0.60
}

qualifying_grid = {
    'Verstappen': 1,
    'Leclerc': 2,
    'Norris': 3,
    'Piastri': 4,
    'Hamilton': 5,
    'Russell': 6,
    'Sainz': 7,
    'Alonso': 8,
    'Gasly': 9,
    'Stroll': 10
}

df_drivers['Abu_Dhabi_Performance'] = df_drivers['Driver'].map(abu_dhabi_performance)
df_drivers['Qualifying_Position'] = df_drivers['Driver'].map(qualifying_grid)

# CALCULATE WIN PROBABILITIES
print("
📈 CALCULATING WIN PROBABILITIES...")
print("-"*50)

weights = {
    'current_form': 0.30,      # Recent performance
    'abu_dhabi_history': 0.25,  # Track record at Abu Dhabi
    'qualifying': 0.20,        # Starting position
    'team_performance': 0.15,   # Car performance
    'experience': 0.10         # Experience factor
}

def calculate_win_probability(row):
    # Current form (based on recent races)
    form_score = row['Recent_Form']
    
    # Abu Dhabi performance
    track_score = row['Abu_Dhabi_Performance']
    
    # Qualifying position (lower = better)
    qual_score = 1 - ((row['Qualifying_Position'] - 1) / 19)
    
    # Team performance
    if row['Team'] == 'Red Bull':
        team_score = 0.9
    elif row['Team'] in ['Mercedes', 'Ferrari']:
        team_score = 0.8
    elif row['Team'] == 'McLaren':
        team_score = 0.7
    else:
        team_score = 0.6
    
    # Experience (more experience helps in Abu Dhabi)
    exp_score = min(row['Experience_Years'] / 20, 1)
    
    # Weighted total
    total_score = (form_score * weights['current_form'] +
                   track_score * weights['abu_dhabi_history'] +
                   qual_score * weights['qualifying'] +
                   team_score * weights['team_performance'] +
                   exp_score * weights['experience'])
    
    return total_score

df_drivers['Win_Score'] = df_drivers.apply(calculate_win_probability, axis=1)
total_score = df_drivers['Win_Score'].sum()
df_drivers['Win_Probability'] = (df_drivers['Win_Score'] / total_score) * 100
df_drivers = df_drivers.sort_values('Win_Probability', ascending=False)

# DISPLAY PREDICTIONS
print("
" + "="*70)
print("🏆 F1 2025 ABU DHABI GRAND PRIX - WINNER PREDICTION")
print("="*70)

print("
📊 PREDICTED WIN PROBABILITIES:")
print("-"*65)

for idx, row in df_drivers.iterrows():
    driver = row['Driver']
    team = row['Team']
    prob = row['Win_Probability']
    qual = row['Qualifying_Position']
    
    medal = ""
    if idx == 0:
        medal = "🥇 "
    elif idx == 1:
        medal = "🥈 "
    elif idx == 2:
        medal = "🥉 "
    else:
        medal = "   "
    
    print(f"{medal}{driver:12s} → {prob:5.1f}%  |  Team: {team:15s} |  Qual: P{qual}")

print("
" + "="*70)
winner = df_drivers.iloc[0]['Driver']
winner_prob = df_drivers.iloc[0]['Win_Probability']
winner_team = df_drivers.iloc[0]['Team']
print(f"🎯 PREDICTED WINNER: {winner}")
print(f"📈 WIN PROBABILITY: {winner_prob:.1f}%")
print(f"🏎️  TEAM: {winner_team}")
print("="*70)

# VISUALIZATION
print("
📊 CREATING VISUALIZATIONS...")
print("-"*50)

plt.figure(figsize=(15, 10))

# Plot 1: Win probabilities
plt.subplot(2, 2, 1)
colors = ['gold' if i==0 else 'silver' if i==1 else '#cd7f32' if i==2 else 'skyblue' 
          for i in range(len(df_drivers))]
bars = plt.barh(df_drivers['Driver'], df_drivers['Win_Probability'], color=colors)
plt.xlabel('Win Probability (%)', fontsize=12)
plt.title('Abu Dhabi GP 2025 - Win Probabilities', fontsize=14, fontweight='bold')
plt.gca().invert_yaxis()

for bar in bars:
    width = bar.get_width()
    plt.text(width + 0.5, bar.get_y() + bar.get_height()/2, 
             f'{width:.1f}%', ha='left', va='center', fontsize=10, fontweight='bold')

# Plot 2: Team comparison
plt.subplot(2, 2, 2)
team_totals = df_drivers.groupby('Team')['Win_Probability'].sum().sort_values()
plt.barh(team_totals.index, team_totals.values, color='lightcoral')
plt.xlabel('Total Win Probability (%)', fontsize=12)
plt.title('Team Performance Prediction', fontsize=14, fontweight='bold')
for i, (team, prob) in enumerate(zip(team_totals.index, team_totals.values)):
    plt.text(prob + 0.5, i, f'{prob:.1f}%', va='center', fontsize=10)

# Plot 3: Key factors for top 3 drivers
plt.subplot(2, 2, 3)
top_drivers = df_drivers.head(3)['Driver'].tolist()
factors = ['Recent_Form', 'Abu_Dhabi_Performance', 'Qualifying_Position']
factor_labels = ['Recent Form', 'Abu Dhabi
History', 'Qualifying
Position']

x = np.arange(len(factor_labels))
width = 0.25

for i, driver in enumerate(top_drivers):
    driver_data = df_drivers[df_drivers['Driver'] == driver]
    values = [driver_data[factor].values[0] for factor in factors]
    # Normalize qualifying (reverse scale)
    values[2] = 1 - (values[2] / 20)
    plt.bar(x + i*width, values, width, label=driver)

plt.xlabel('Performance Factors', fontsize=12)
plt.ylabel('Normalized Score (0-1)', fontsize=12)
plt.title('Top 3 Drivers - Key Performance Factors', fontsize=14, fontweight='bold')
plt.xticks(x + width, factor_labels)
plt.legend()

# Plot 4: Experience vs Win Probability
plt.subplot(2, 2, 4)
plt.scatter(df_drivers['Experience_Years'], df_drivers['Win_Probability'], 
            s=150, alpha=0.7, c='green', edgecolors='black')

for i, row in df_drivers.iterrows():
    plt.annotate(row['Driver'], 
                 (row['Experience_Years'], row['Win_Probability']),
                 xytext=(8, 8), textcoords='offset points', 
                 fontsize=9, fontweight='bold')

plt.xlabel('Experience (Years)', fontsize=12)
plt.ylabel('Win Probability (%)', fontsize=12)
plt.title('Experience vs Win Probability', fontsize=14, fontweight='bold')
plt.grid(True, alpha=0.3)

plt.tight_layout()
plt.show()

# SAVE RESULTS
print("
💾 SAVING PREDICTION RESULTS...")
print("-"*50)

import json
from datetime import datetime

results = {
    'prediction_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    'race': '2025 Abu Dhabi Grand Prix',
    'circuit': 'Yas Marina Circuit',
    'predicted_winner': df_drivers.iloc[0]['Driver'],
    'winner_probability': float(df_drivers.iloc[0]['Win_Probability']),
    'winner_team': df_drivers.iloc[0]['Team'],
    'top_3_predictions': df_drivers.head(3)[['Driver', 'Team', 'Win_Probability']].to_dict('records'),
    'all_predictions': df_drivers[['Driver', 'Team', 'Win_Probability', 'Qualifying_Position']].to_dict('records'),
    'methodology': 'Weighted scoring based on: Current form (30%), Abu Dhabi history (25%), Qualifying position (20%), Team performance (15%), Experience (10%)',
    'weights_used': weights
}

with open('f1_abu_dhabi_2025_prediction.json', 'w') as f:
    json.dump(results, f, indent=4)

df_drivers.to_csv('f1_abu_dhabi_2025_predictions.csv', index=False)

print("✅ RESULTS SAVED:")
print("   📄 f1_abu_dhabi_2025_prediction.json")
print("   📊 f1_abu_dhabi_2025_predictions.csv")

# FINAL SUMMARY
print("
" + "="*70)
print("📋 PREDICTION SUMMARY")
print("="*70)
print(f"   Race: 2025 Abu Dhabi Grand Prix")
print(f"   Circuit: Yas Marina Circuit")
print(f"   Date: {results['prediction_date']}")
print(f"   Predicted Winner: {results['predicted_winner']}")
print(f"   Win Probability: {results['winner_probability']:.1f}%")
print(f"   Team: {results['winner_team']}")
print(f"   Methodology: {results['methodology'][:80]}...")
print("="*70)

print("
🎉 PREDICTION MODEL COMPLETE!")
print("🔗 GitHub Repository: https://github.com/gotnochill815-web/F1-2025-Abu-Dhabi-GP-Winner-Prediction-Model")