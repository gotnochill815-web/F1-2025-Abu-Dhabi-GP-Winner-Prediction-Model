# F1 2025 Abu Dhabi GP Winner Prediction Model

## Overview
Machine Learning model to predict the winner of 2025 Abu Dhabi Grand Prix.

## Files
- Main notebook with prediction model
- Requirements file
- Supporting scripts

## Usage
Open the notebook in Google Colab or Jupyter.

## Author
gotnochill815-web
